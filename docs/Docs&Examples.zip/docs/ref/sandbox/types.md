# `Types`

::: agents.sandbox.types
