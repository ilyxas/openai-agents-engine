# `Errors`

::: agents.sandbox.errors
