# `Files`

::: agents.sandbox.files
